package IGP_workflow;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IGP_workflow_test {	
	ChromeDriver driver=new ChromeDriver();
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	String product_url="https://www.igp.com/p-burst-of-blooms-bouquet-223320";
	String selected_product_titles="Burst Of Blooms Bouquet";
	@BeforeTest
	//lunch IGP site
	public void IGP_lunch() throws IOException {
		driver.get("https://www.igp.com");
		driver.manage().window().maximize();
		String actual=driver.getCurrentUrl();
		common.writeData(1, 4, actual);
		if(actual.equals(common.readData(1, 3)))common.writeData(1, 5, "PASS");
		else common.writeData(1, 5, "FAIL");
	}
	
	@Test(priority = 1, enabled = true)
	public void User_Profile_click() throws IOException {
		driver.findElement(By.cssSelector("img#img-black")).click();
		String actual=driver.getCurrentUrl();
		common.writeData(2, 4, actual);
		if(actual.equals(common.readData(2, 3)))common.writeData(2, 5, "PASS");
		else common.writeData(2, 5, "FAIL");
	}
	
	@Test(priority = 2, enabled = true)
	public void User_login() throws IOException, InterruptedException {
		driver.findElement(By.id("email")).sendKeys("testbhushan487@bhushan.com");
		driver.findElement(By.id("passwd")).sendKeys("bhushan@3214");
		driver.findElement(By.id("row-submit")).click();
		Thread.sleep(3000);
		String actual=driver.getCurrentUrl();
		common.writeData(3, 4, actual);
		if(actual.equals(common.readData(3, 3))) {
			common.writeData(3, 5, "PASS");
		}
		else if(actual.equals(common.readData(2, 4))) {
			//sleep
			Thread.sleep(3000);
			WebElement error=driver.findElement(By.className("error_txt"));
			if(error.isDisplayed()) {
			common.writeData(3, 5, "Invalid credentials: FAIL");
			}
		}
		else common.writeData(3, 5, "FAIL");
	}

	@Test(priority = 3, enabled = true)
	public void Search_product() throws IOException {
		driver.findElement(By.cssSelector("input[name=\'q\']")).sendKeys("Flower");
		driver.findElement(By.cssSelector("form#search-products img")).click();
		String actual=driver.getCurrentUrl();
		common.writeData(4, 4, actual);
		if(actual.equals(common.readData(4, 3)))common.writeData(4, 5, "PASS");
		else common.writeData(4, 5, "FAIL");
	}
	
	@Test(priority = 4, enabled = true)
	public void productSort_By_dropdown() throws IOException, InterruptedException {
		driver.findElement(By.cssSelector("div#site-wrapper div.row.p-20.no-margin > div:nth-child(1) > div:nth-child(2) > div > div.c-dd-text.text-right.igp-revamp-sort-by > span.c-dd-s-text.sort-value.Paragraph-12-XS--Semibold")).click();
		driver.findElement(By.xpath("//*[@id=\'site-wrapper\']/div/section[1]/div/div[1]/div[1]/div[2]/div/div[2]/ul/li[3]")).click();
		WebElement actual=driver.findElement(By.xpath("//*[@id=\'site-wrapper\']/div/section[1]/div/div[1]/div[1]/div[2]/div/div[1]/span[1]"));
		Thread.sleep(3000);
		String actualtext=actual.getText();
		common.writeData(5, 4, actualtext);
		if(actualtext.equals(common.readData(5, 3)))common.writeData(5, 5, "PASS");
		else common.writeData(5, 5, "FAIL");
	}
	
	@Test(priority = 5, enabled = true)
	public void Product_click() throws IOException, InterruptedException {
		//*[@id="product-grid"]/div[1]/div/a
		driver.findElement(By.xpath("//*[@id=\'product-grid\']/div[2]/div/div[1]/a")).click();
		String firstWindowHandle = driver.getWindowHandle();
		String product=driver.getCurrentUrl();
		common.writeData(6, 4, product);
		if(product.equals(common.readData(6, 3)))common.writeData(6, 5, "PASS");
		else common.writeData(6, 5, "FAIL");
		
		//two window handles
		Set<String> allWindowHandles = driver.getWindowHandles();
        Iterator<String> iterator = allWindowHandles.iterator();
        String secondWindowHandle = "";
        while (iterator.hasNext()) {
            String handle = iterator.next();
            if (!handle.equals(firstWindowHandle)) {
                driver.switchTo().window(handle);
                secondWindowHandle = handle;
                break;
            }
        }
        driver.close();
        driver.switchTo().window(firstWindowHandle);
	}
	
	@Test(priority = 6, enabled = true)
	public void enter_pincode() throws IOException, InterruptedException {
		 driver.get("https://www.igp.com/p-burst-of-blooms-bouquet-223320");
		System.out.println(driver.getCurrentUrl());
        //pincode check
		driver.findElement(By.xpath("//*[@id=\'location-input\']")).sendKeys("400059");
		Thread.sleep(3000);
		WebElement error=driver.findElement(By.xpath("//*[@id=\'p-check-form\']/div/div/div[4]/button[3]"));
	
		if(driver.findElement(By.id("available-pincode")).isDisplayed())common.writeData(7, 5, "PASS");
		else if (error.isDisplayed()) {
			WebElement error_message=driver.findElement(By.xpath("//*[@id=\'pin-error-text\']/p"));
			String error_message_text=error_message.getText();
			if(common.readData(7, 3).equals(error_message_text) && error_message.isDisplayed()) {
			common.writeData(7, 4, error_message_text);
			common.writeData(7, 5, "FAIL");
			}
			else {
				common.writeData(7, 5, "Actual Error message not matched with expected: FAIL");
			}
		}
		else common.writeData(7, 5, "FAIL");

	}
	
	@Test(priority = 7, enabled = true)
	public void select_date() throws IOException, InterruptedException {
		driver.findElement(By.cssSelector("div#domestic-del div.schedule_delivery_heading.delivery_cont_heading.Paragraph-12-XS--Regular")).click();
		//Select date
		WebElement alldates_button=driver.findElement(By.xpath("//*[@id=\'domestic-del\']/div[1]/div[7]/div[1]/div[2]"));
		List<WebElement> dates_button= alldates_button.findElements(By.tagName("button"));
		for(int i=0;i<dates_button.size();i++) {
		String selectdate=dates_button.get(i).getText();
		WebElement date_Text= driver.findElement(By.id("country"));
		int yCoordinate = date_Text.getLocation().getY();
	    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, arguments[0]);", yCoordinate);
		if(selectdate.contains("Select Date")) {
			dates_button.get(i).click();
			WebElement calender=driver.findElement(By.id("ui-datepicker-div"));
			List<WebElement> calender_table_row=driver.findElements(By.tagName("td"));
			for(int j=0;j<calender_table_row.size();j++) {
				String calender_table_selectdate=calender_table_row.get(j).getText();
				if(calender_table_selectdate.equals("28")) {
				  	calender.findElement(By.xpath("//*[@id=\'ui-datepicker-div\']/table/tbody/tr[5]/td[5]/a")).click();
				}
				}
		}
	//	System.out.println((dates_button.get(i).getText()));

		}
		WebElement displyed_date=driver.findElement(By.xpath("//*[@id=\'show-Select_Date\']"));
		String displyed_date_text=displyed_date.getText();
		System.out.println(displyed_date_text);
		if(common.readData(9, 3).equals(displyed_date_text)) {
		common.writeData(9, 5, "PASS");
		common.writeData(9, 4, "Selected date:-"+displyed_date_text);
		}
		else common.writeData(9, 5, "FAIL");
	}
	
	@Test(priority = 8, enabled = true)
	public void Select_delivery_type() throws IOException, InterruptedException {
		WebElement delivery=driver.findElement(By.xpath("//*[@id=\"domestic-del\"]/div[1]/div[7]/div[1]/div[4]/div[2]"));
		List<WebElement> delivery_button= delivery.findElements(By.tagName("button"));
		for(int i=0;i<delivery_button.size();i++) {
		String select_type=delivery_button.get(i).getText();
		if(select_type.contains("Standard")) {
			delivery_button.get(i).click();
			String actual=delivery_button.get(i).getCssValue("color");
			if(actual.contains("rgba(109, 78, 191, 1)"))common.writeData(10, 5, "PASS");
			else common.writeData(10, 5, "FAIL");
		 }
		}
	}
	
	@Test(priority = 9, enabled = true)
	public void Select_Time() throws IOException, InterruptedException {
//		//Select Time
	    WebElement Time_dropdown=driver.findElement(By.id("timepicker"));
	    Time_dropdown.click();
	    List<WebElement> Time_sloat=Time_dropdown.findElements(By.tagName("option"));
	  
	    	String dropdown_value=Time_sloat.get(1).getText();
	    	Time_sloat.get(1).click();
	    	if(Time_sloat.get(1).isDisplayed()) {
	    		common.writeData(11, 4, dropdown_value);
		    	common.writeData(11, 5, "PASS");
	    	}
	    	else common.writeData(11, 5, "FAIL");
	    
	}
	
	@Test(priority = 10, enabled = true)
	public void add_to_card() throws IOException, InterruptedException {
		 //add to card
		WebElement card=driver.findElement(By.id("add-cart"));
		card.click();
		WebElement addons= driver.findElement(By.id("accordion"));
		if(addons.isDisplayed() && card.isDisplayed())common.writeData(12, 5, "PASS");
		else common.writeData(12, 5, "FAIL");
		Thread.sleep(2000);
	}
	
	@Test(priority = 11, enabled = true)
	public void Click_on_X() throws IOException, InterruptedException {
		//Click on X Button	
		WebElement close=driver.findElement(By.id("close-modal"));
		close.click();
		if(close.isDisplayed())common.writeData(13, 5, "FAIL");
		else common.writeData(13, 5, "PASS");
		//Thread.sleep(3000);	
	}
	
	@Test(priority = 12, enabled = true)
	public void Proceed_to_Cart_Button() throws IOException, InterruptedException {
		WebElement card=driver.findElement(By.id("add-cart"));
		card.click();
	}
	
	@Test(priority = 13, enabled = true)
	public void Shopping_Cart_header_check() throws IOException, InterruptedException {
		Thread.sleep(3000);
		WebElement logo=driver.findElement(By.xpath("//*[@id=\'header\']/div[1]/div[1]/a/img"));
	    if(logo.isDisplayed()) common.writeData(15, 5, "PASS");
		else common.writeData(15, 5, "FAIL");
	    WebElement search_bar=driver.findElement(By.id("morphsearch"));
	    if(search_bar.isDisplayed()) common.writeData(16, 5, "PASS");
		else common.writeData(16, 5, "FAIL");

	
	  WebElement header_product_Cart=driver.findElement(By.xpath("//*[@id=\'header\']/div[1]/div[3]/div"));
	  List<WebElement> header_product_Cart_img=header_product_Cart.findElements(By.tagName("img"));
	  
	    for(int i=0;i<header_product_Cart_img.size();i++) {
	    //System.out.println(header_image.get(i).getAttribute("alt"));
	    if(header_product_Cart_img.get(i).isDisplayed())common.writeData(17, 5, "PASS");
		else common.writeData(17, 5, "FAIL");
	    }
	    
	    WebElement userprofile= driver.findElement(By.id("user-menu"));
	    if(userprofile.isDisplayed()) common.writeData(18, 5, "PASS");
		else common.writeData(18, 5, "FAIL");
	    
	}
	
	@Test(priority = 14, enabled = true)
	public void Shopping_Cart_details() throws IOException, InterruptedException {
		//product check
		WebElement cart_details=driver.findElement(By.xpath("//*[@id=\'site-wrapper\']/div/div[3]/div/div/div[1]"));
		List<WebElement> cart_details_image=cart_details.findElements(By.tagName("img"));
		//List<WebElement> cart_details_p=cart_details.findElements(By.tagName("p"));
		for(int i=0;i<cart_details_image.size();i++) {
		   // System.out.println(cart_details_image.get(i).getAttribute("alt"));
		    if(cart_details_image.get(i).isDisplayed())common.writeData(21, 5, "PASS");
			else common.writeData(21, 5, "FAIL");
		    }
		//product text
		WebElement actual_text_p= driver.findElement(By.xpath("//*[@id=\'site-wrapper\']/div/div[3]/div/div/div[1]/div[1]/div[2]/a"));
	    if(actual_text_p.isDisplayed()) common.writeData(19, 5, "PASS");
	    else common.writeData(19, 5, "FAIL");
        //prize
		WebElement prize= driver.findElement(By.id("s-total-val-617865"));
		    String prize_vlaue=prize.getText();
		    common.writeData(20, 3, prize_vlaue);
		    if(prize.isDisplayed())common.writeData(20, 5, "PASS");
			else common.writeData(20, 5, "FAIL");	  
	    
	}

	@Test(priority = 15, enabled = true)
	public void product_cart_footer() throws IOException, InterruptedException {
			WebElement Total_Products = driver.findElement(By.xpath("//*[@id=\'site-wrapper\']/div/div[5]/div[1]/div[1]/p"));
			WebElement Total_Amount = driver.findElement(By.xpath("//*[@id=\'site-wrapper\']/div/div[5]/div[1]/div[3]/p"));
		    if(Total_Products.isDisplayed() && Total_Amount.isDisplayed() ) common.writeData(22, 5, "PASS");
		    else common.writeData(22, 5, "FAIL");	        
	}
	
	@Test(priority = 16, enabled = true)
	public void proceed_checkout() throws IOException, InterruptedException {
		//product footer check
		   WebElement proceed_checkout_button=driver.findElement(By.id("enabled-button"));
		    if(proceed_checkout_button.isDisplayed()) common.writeData(23, 5, "PASS");
		    else common.writeData(23, 5, "FAIL");	 
		    proceed_checkout_button.click();
		    Thread.sleep(3000);
		    String checkout_url= driver.getCurrentUrl(); 
		    if(checkout_url.contains(common.readData(24, 3))) common.writeData(24, 5, "PASS");
		    else common.writeData(24, 5, "FAIL");	        
	}
	
	
	
	@Test(priority = 17, enabled = true)
	public void required_check() throws IOException, InterruptedException {
	
	        String[] labelSelectors = {
	        		"div.address-form-label", 
	                "label.address-form-label", 
	                "label.rev-pincode.address-form-label"
	        };
	        for (String selector : labelSelectors) {
	            // Execute JavaScript code to retrieve the label value
	            String script = "return document.querySelector('" + selector + "').innerText;";
	            String labelValue = (String) jse.executeScript(script); 
	            if(labelValue.contains("*")) common.writeData(25, 5, "PASS");
	            else common.writeData(25, 5, "FAIL"); 
	        }
	  
	}
	@Test(priority = 18, enabled = true)
	public void checkout_from() throws IOException, InterruptedException {
		
	     
			 WebElement name = driver.findElement(By.cssSelector("input[name=\"fname\"]"));
			 WebElement country = driver.findElement(By.cssSelector("input#countName"));
			 WebElement zipcode = driver.findElement(By.cssSelector("input#location-input"));
			 WebElement adderess1 = driver.findElement(By.cssSelector("input[name=\"saddr\"]"));

			 WebElement city = driver.findElement(By.id("new-city"));
			 WebElement state = driver.findElement(By.id("new-state"));
			 WebElement adderess2 = driver.findElement(By.cssSelector("input[name=\"saddr2\"]"));
			 WebElement m_number = driver.findElement(By.cssSelector("input[placeholder=\"Mobile Number\"]"));
			 WebElement a_m_number = driver.findElement(By.cssSelector("input[name=\"alternateMob\"]"));
			 WebElement email = driver.findElement(By.cssSelector("input#e-form-email-"));
			 WebElement Address_type = driver.findElement(By.cssSelector("form#c-add-add-flow label:nth-child(4)"));
		
		//form fill
	      jse.executeScript("arguments[0].value = 'test do not deliver'", name);
	      jse.executeScript("arguments[0].value = 'India'", country);
	      jse.executeScript("arguments[0].value = '400059'", zipcode);
	      jse.executeScript("arguments[0].value = 'test do not deliver'", adderess1);
	      jse.executeScript("arguments[0].value = 'test do not deliver'", adderess2);
	      jse.executeScript("arguments[0].value = '8899889989'", a_m_number);
	      jse.executeScript("arguments[0].value = 'test@test.com'", email);
	      jse.executeScript("arguments[0].value = 'test do not deliver'", m_number);
	      jse.executeScript("arguments[0].click()", Address_type);
	       Thread.sleep(2000);
	      jse.executeScript("arguments[0].value = '8899889988'", m_number);    
	      WebElement date_Text= driver.findElement(By.cssSelector("form#c-add-add-flow button[type=\'submit\']"));
	 	  int yCoordinate = date_Text.getLocation().getY();
		    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, arguments[0]);", yCoordinate);
		    jse.executeScript("arguments[0].click()", date_Text);
	}
	
	
	//@Test(priority = 19, enabled = false)
//	public void ordersummery() throws IOException, InterruptedException {
//		Thread.sleep(3000);
//		 JavascriptExecutor jse = (JavascriptExecutor) driver;
//		 String productName = (String) jse.executeScript("return document.querySelector('.para.font.Paragraph-14-S--Regular').textContent");
//
//		// Retrieve the text of the second label
//		String productPrice = (String) jse.executeScript("return document.querySelector('.colour-change.Paragraph-16-M--Bold.lh-20--S').textContent");
//
//		// Retrieve the text of the third label
//		String productQty = (String) jse.executeScript("return document.querySelector('.qty-amt.revamp-prod-price').textContent");
//
//		// Retrieve the text of the fourth label
//		String totalAmount = (String) jse.executeScript("return document.getElementById('cart-total-val').textContent");
//
//		// Print the retrieved label values
//		System.out.println("Product Name: " + productName);
//		System.out.println("Product Price: " + productPrice);
//		System.out.println("Product Quantity: " + productQty);
//		System.out.println("Total Amount: " + totalAmount);

//	if(product_text.equals(common.readData(26, 3))) common.writeData(26, 5, "PASS");
//	else common.writeData(26, 5, "FAIL");
//	}
	

	@Test(priority = 19 , enabled = true)
	public void Coupon_Code() throws IOException, InterruptedException {
		Thread.sleep(3000);
		 WebElement coupon = driver.findElement(By.cssSelector("li#order-summary-wrpr div.coupon-txt.revamp-coupon-txt.coupon-apply-cont.Paragraph-14-S--Regular > span"));
		Thread.sleep(3000);
		 // coupon.click();
		 WebElement coupon_field=driver.findElement(By.id("coupon"));
		 WebElement coupon_apply=driver.findElement(By.xpath("//*[@id=\'coupon-form\']/div/div[2]/button"));
		 WebElement procced_to_checkout=driver.findElement(By.cssSelector(".btn-mr.u-case.order-summ-chkout.revamp-payment-button"));
		 jse.executeScript("arguments[0].click()", coupon);
		 jse.executeScript("arguments[0].value = 'IGP10'", coupon_field);
		 jse.executeScript("arguments[0].click()", coupon_apply);
		 jse.executeScript("arguments[0].click()", procced_to_checkout);
	}
	
	
	@Test(priority = 20, enabled = true)
	public void payment() throws IOException, InterruptedException {
		
	Thread.sleep(3000);
	//url check
	String checkpayment_url=driver.getCurrentUrl();
	System.out.println(checkpayment_url);
	if(checkpayment_url.contains(common.readData(28, 3)))common.writeData(28, 5, "PASS");
	else common.writeData(28, 5, "FAIL");
	//prize check
    WebElement total_payment = driver.findElement(By.cssSelector("li#payment-wrpr div.payment-amt-title.payment-container-block.payment-container-revamp.without-guest > div.total-amount.Paragraph-16-M--Semibold > span.amount-tb-paid.m_color_scheme_txt.Paragraph-20-XL--Semibold"));
    if(total_payment.isDisplayed())common.writeData(29, 5, "PASS");
	else common.writeData(29, 5, "FAIL");
	//adderess check
	WebElement address=driver.findElement(By.xpath("//*[@id=\'site-wrapper\']/div/section/div[3]/div[3]"));
	if(address.isDisplayed())common.writeData(30, 5, "PASS");
	else common.writeData(30, 5, "FAIL");

	//Thread.sleep(3000);
		   //JavascriptExecutor to click element
		 WebElement UPI = driver.findElement(By.xpath("//*[@id=\'payment-wrpr\']/div/div[1]/div/div[4]/ul/li[4]"));
		 WebElement make_a_payment=driver.findElement(By.xpath("//*[@id=\'UPI-form\']/button"));		
		 jse.executeScript("arguments[0].click()", UPI);
		 Thread.sleep(1000);
		 jse.executeScript("arguments[0].click()", make_a_payment);
	}
	
	@Test(priority = 21, enabled = true)
	public void payment_gateway() throws IOException, InterruptedException {
	Thread.sleep(3000);
	//url check
	String checkpayment_url=driver.getCurrentUrl();
	System.out.println(checkpayment_url);
	if(checkpayment_url.contains(common.readData(31, 3)))common.writeData(31, 5, "PASS");
	else common.writeData(31, 5, "FAIL");
	}
	
	@Test(priority = 22, enabled = true)
	public void cleanup() throws IOException, InterruptedException {
		driver.navigate().to("https://www.igp.com/");
		driver.findElement(By.cssSelector("div#user-menu > div")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector("div#acc-menu div:nth-child(3) > div > a:nth-child(1) > span")).click();
	    Thread.sleep(3000);
		driver.findElement(By.linkText("Address Book")).click();
		WebElement edit=driver.findElement(By.cssSelector("ul#shipping-addr-list div.flex-row.justify-content-space-between.relative > div > div.address-actions-edit.icon.addres-edit-button-revamp.Paragraph-14-S--Semibold"));
		
			edit.click();
			WebElement delete= driver.findElement(By.cssSelector("form#c-add-edit-flow div.revamp-delete-address"));
		 	int yCoordinate = delete.getLocation().getY();
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0, arguments[0]);", yCoordinate);
			jse.executeScript("arguments[0].click()", delete);
			Thread.sleep(2000);
			driver.findElement(By.linkText("YES")).click();
	
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("span#cart-count")).click();
		WebElement delete_button=driver.findElement(By.id("cart-item-remove-container-617865"));
		
		delete_button.click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("YES")).click();
		
	}
	
	@AfterTest 
	public void close() {
		//driver.close();
	}
	
}
