package IGP_workflow;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class common {
	
	private static final String filesource="C:\\Users\\bhush\\OneDrive\\Desktop\\IGP_Script\\src\\test\\java\\IGP_workflow\\Assignment Question- Bhushan.xlsx";
	public static String readData(int row, int column) throws IOException {
        FileInputStream fis = new FileInputStream(filesource);
        XSSFWorkbook workbook=new XSSFWorkbook(fis);
        XSSFSheet sheet=workbook.getSheet("Script");
        XSSFRow r;
        r = sheet.getRow(row);
        XSSFCell cell = r.getCell(column);
        return cell.getStringCellValue();
    }

    public static void writeData(int row, int column, String value) throws IOException {
        FileInputStream fis = new FileInputStream(filesource);
        XSSFWorkbook workbook=new XSSFWorkbook(fis);
        XSSFSheet sheet=workbook.getSheet("Script");
        XSSFRow r;
        r = sheet.getRow(row);
        XSSFCell cell = r.createCell(column);
        cell.setCellValue(value);
        FileOutputStream fos = new FileOutputStream(filesource);
        workbook.write(fos);
        fos.close();
    }

  
    

}
